//
//  User.m
//  DamnVulnerableIOSApp
//
//  Created by Prateek Gianchandani on 12/30/13.
//  Copyright (c) 2013 HighAltitudeHacks.com. All rights reserved.
//

#import "User.h"

@implementation User

@dynamic name;
@dynamic phone;
@dynamic email;
@dynamic password;

@end
