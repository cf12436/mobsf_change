//
//  FlurrySecondChallengeViewController.h
//  DamnVulnerableIOSApp
//
//  Created by Egor Tolstoy on 17/05/15.
//  Copyright (c) 2015 HighAltitudeHacks.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlurrySecondChallengeViewController : UIViewController

@end
