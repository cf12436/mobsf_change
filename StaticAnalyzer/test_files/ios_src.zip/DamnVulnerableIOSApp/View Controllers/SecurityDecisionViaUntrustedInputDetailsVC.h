//
//  SecurityDecisionsViaUntrustedInputDetailsVC.h
//  DamnVulnerableIOSApp
//
//  Created by Prateek Gianchandani on 2/11/14.
//  Copyright (c) 2014 HighAltitudeHacks.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecurityDecisionsViaUntrustedInputDetailsVC : UIViewController

@property (nonatomic,assign) NSInteger vulnCode;

@end
